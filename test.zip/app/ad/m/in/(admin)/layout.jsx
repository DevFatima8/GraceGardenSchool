'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { logoutAdmin } from '../actions';

export default function AdminLayout({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [isAboutDropdownOpen, setIsAboutDropdownOpen] = useState(false);

  const handleLogout = async () => {
    await logoutAdmin();
    router.push('/ad/m/in');
  };

  const isActive = (path) => pathname === path;
  const isPagesActive = pathname.startsWith('/ad/m/in/pages');

  let pageTitle = 'Admin Portal';
  if (pathname.includes('/pages')) pageTitle = 'Website Content Management';
  if (pathname.includes('/settings')) pageTitle = 'Admin Settings';

  return (
    <div className="d-flex vh-100 bg-light">
      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .btn-primary {
          background-color: var(--primary-color-1) !important;
          border-color: var(--primary-color-1) !important;
        }
        .text-primary {
          color: var(--primary-color-1) !important;
        }
        .bg-primary {
          background-color: var(--primary-color-1) !important;
        }
        .border-primary {
          border-color: var(--primary-color-1) !important;
        }
        .btn-outline-primary {
          color: var(--primary-color-1) !important;
          border-color: var(--primary-color-1) !important;
        }
        .btn-outline-primary:hover {
          background-color: var(--primary-color-1) !important;
          color: white !important;
        }
        .form-select:focus, .form-control:focus {
          border-color: var(--primary-color-1) !important;
          box-shadow: 0 0 0 0.25rem rgba(0, 166, 81, 0.25) !important;
        }
      `}</style>
      {/* Sidebar */}
      <div className="text-white d-flex flex-column" style={{ width: '280px', flexShrink: 0, backgroundColor: 'var(--dark-one)' }}>
        <div className="p-4 border-bottom border-secondary text-center">
          <Link href="/">
             <img src="/assets/img/logo-2.jpg" alt="Grace Garden School" style={{ maxHeight: '60px' }} />
          </Link>
          <h6 className="fw-bold mt-3 mb-0 text-white-50">Admin Portal</h6>
        </div>
        
        <div className="flex-grow-1 p-3 hide-scrollbar" style={{ overflowY: 'auto', overflowX: 'hidden' }}>
          <ul className="nav nav-pills flex-column mb-auto">
            
            {/* Pages Section */}
            <li className="nav-item mb-2">
              <Link href="/ad/m/in/pages/home" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/pages/home') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/pages/home') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-home me-2"></i> Home Page
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link href="/ad/m/in/pages/about" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/pages/about') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/pages/about') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-info-circle me-2"></i> About Us
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link href="/ad/m/in/pages/our-school" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/pages/our-school') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/pages/our-school') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-school me-2"></i> Our School
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link href="/ad/m/in/pages/classes" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/pages/classes') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/pages/classes') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-chalkboard-teacher me-2"></i> Classes
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link href="/ad/m/in/pages/departments" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/pages/departments') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/pages/departments') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-building me-2"></i> Departments
              </Link>
            </li>

            <li className="nav-item mb-2">
              <Link href="/ad/m/in/pages/misc" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/pages/misc') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/pages/misc') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-layer-group me-2"></i> Other Pages
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link href="/ad/m/in/pages/team" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/pages/team') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/pages/team') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-users me-2"></i> Teachers / Team
              </Link>
            </li>

            <li className="nav-item mb-2 mt-4">
              <Link href="/ad/m/in/settings" className={`nav-link text-start w-100 py-2 ${isActive('/ad/m/in/settings') ? 'text-white fw-bold' : 'text-white-50'}`} style={isActive('/ad/m/in/settings') ? { backgroundColor: 'var(--primary-color-1)' } : {}}>
                <i className="far fa-cog me-2"></i> Settings
              </Link>
            </li>
          </ul>
        </div>
        
        <div className="p-3 border-top border-secondary">
          <button onClick={handleLogout} className="btn btn-outline-light w-100 text-start">
            <i className="far fa-sign-out-alt me-2"></i> Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 overflow-auto">
        {/* Top Navbar Component */}
        <div className="bg-white px-4 py-3 shadow-sm d-flex justify-content-between align-items-center mb-4 sticky-top">
          <h5 className="mb-0 fw-semibold text-dark">
            {pageTitle}
          </h5>
          <div className="d-flex align-items-center">
            <span className="text-muted me-3">Admin User</span>
            <div className="text-white rounded-circle d-flex align-items-center justify-content-center" style={{ width: '40px', height: '40px', backgroundColor: 'var(--primary-color-1)' }}>
              <i className="fal fa-user"></i>
            </div>
          </div>
        </div>

        {/* Dynamic Page Content */}
        <div className="px-4 pb-5">
          {children}
        </div>
      </div>
    </div>
  );
}
